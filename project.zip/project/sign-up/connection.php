<?php

 $f = $_POST['first'];
 $l = $_POST['last'];
 $m = $_POST['mail'];
 $p = $_POST['password'];

 $con=mysqli_connect('localhost','root');

 mysqli_select_db($con,'data');
 $q = "insert into info (first,last,mail,password) values ('$f','$l','$m','$p')";
 mysqli_query($con,$q);
 echo "Registered successfully !, Go back and Login";
 mysqli_close($con);

?>