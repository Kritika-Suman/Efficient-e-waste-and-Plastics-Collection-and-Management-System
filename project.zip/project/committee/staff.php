<?php

  error_reporting(E_PARSE | E_ERROR);
  $u="staff";
  $p="123"; 

  $user = $_POST['username'];
  $pass = $_POST['password'];

  $con=mysqli_connect('localhost','root');
  mysqli_select_db($con,'data');

  if($user==$user && $pass==$p){
      
      $r=mysqli_query($con,"select * from enter");
      $n=mysqli_num_rows($r);  
      
     
      
      for($i=1;$i<=$n;$i++)
      {
          $row=mysqli_fetch_array($r);
          
          
          echo "ID                     : ".$row[3]."<br>";
          echo "DATE                   : ".$row[1]."<br>";
          echo "e-waste(1)/plastics(2) : ".$row[2]."<br><br>";
          
      }
      
  }
  else{
      
      echo "username or password is wrong, try again.";
      
  }
  
  mysqli_close($con);

?>