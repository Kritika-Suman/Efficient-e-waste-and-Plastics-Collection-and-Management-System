<?php
  $d = $_POST['date'];
  $no = $_POST['num'];
  $mail = $_POST['email'];
  
  $con=mysqli_connect('localhost','root');

  mysqli_select_db($con,'data');

  $q = "insert into enter (date,num,email) values ('$d','$no','$mail')";
  mysqli_query($con,$q);
  echo "We will collect your waste at ";
  echo $d;
  echo ".";
  
  echo "\n\n";

  echo "Thank you for contacting us. Have safe and Swachh bharat.";

  mysqli_close($con);

?>