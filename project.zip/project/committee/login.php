<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Login Form</title>
  
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css">

  <link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,500,700,900'>
<link rel='stylesheet prefetch' href='https://fonts.googleapis.com/css?family=Montserrat:400,700'>
<link rel='stylesheet prefetch' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>

      <link rel="stylesheet" href="css/style.css">
    
    <style>
        body{
            background-color: black;
            }
    </style>

</head>

<body>

  
<div class="container" >
  <div class="info" >
      <h1 style="color:white;">Staff Login</h1><span style="color:white;">for</span><br><br><h2 style="color:white;">committee of e-waste and plastics collection and management</h2>
  </div>
</div>
<div class="form">
  <div class="thumbnail"><img src="Staff.png"/></div>
 
  <form class="login-form" action="staff.php" method="post">
    <input type="text" placeholder="username" name="user" />
    <input type="password" placeholder="password" name="password"/>
    <button>login</button>
  </form>
    
</div>
<video id="video" autoplay="autoplay" loop="loop" poster="polina.jpg">
  <source src="http://andytran.me/A%20peaceful%20nature%20timelapse%20video.mp4" type="video/mp4"/>
</video>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
