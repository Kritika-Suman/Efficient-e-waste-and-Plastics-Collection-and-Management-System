<?php

 $m1 = $_POST['user'];
 $p1 = $_POST['pass'];

 $con=mysqli_connect('localhost','root');

 mysqli_select_db($con,'data');

 $r=mysqli_query($con,"select * from info");
 $n=mysqli_num_rows($r);  

 for($i=1;$i<=$n;$i++)
 {
     $row=mysqli_fetch_array($r);
      
     if($row[3]==$m1 && $row[4]==$p1)
     {
      $name = $row[1];
     ?>     
         
      <html>

          <head>
              <style>
                    .div {
                        height: 100px;
                        width: 100%;
                        background-color: yellow; 
                        }
                  
                     body{
                        background-color: black;
                         }
                  
                     .div1{
                        padding-left:5px; 
                        padding-top: 10px; 
                          }
                  
                  .div2{
                       
                       }
                
                  a{
                     text-decoration: none;
                     color: aliceblue;  
                   }
                
              </style>
          </head>

          <body>
              
              <div class="div" >
                 <div class="div1" > 
                  <h2>
                      Welcome <?php echo $name ?>    
                 </h2>  
                     <div style="width:80px; height:30px; border:1px solid black; transform:translateX(1250px); margin-top: -50px; background-color: grey; padding-top:8px; padding-left:8px;" ><a href="signUp.php"><b>LOG OUT</b></a></div> 
                </div> 
              </div>   
    
              <br>
              <br>
              <br>
              
              <div class=div2>
                  
                <div style="width:600px; height:400px; border:1px solid aliceblue; transform:translateX(120px);">
                    <img src="ewaste.jpg" alt="" style="transform:translateX(1px);">
                </div>
                      
              <div style="width:400px; height:140px; border:1px solid aliceblue; color:aliceblue; margin-top:-250px; margin-left: 60%;" >
                
                  <form action="enter.php" method="post">

                      <input type="date" placeholder="Date of Collection" name="date" style="width:400px; heigth:300px; margin-top:25p;text-align:center;">
                      <br>
                      <br>
                      <input type="number" placeholder="Enter 1 for ewaste & 2 for plastics" name="num" style="width:400px; heigth:300px; margin-bottom:25p; text-align:center;">
                      <br>
                      <br>
                      <input type="text" placeholder="Enter registerded email-id" name="email" style="width:400px; heigth:300px; margin-bottom:25p; text-align:center;">
                      <br>
                      <br>
                      <button type="submit" style="width:400px; heigth:300px; margin-bottom:25p; text-align:center;">GO</button>
                      
                  </form>     
    
              </div>   
                  
                 
                     
            </div>
                  
              
          </body>

     </html>   
         
     <?php    
     }
         
     else
         echo "try again";
 }

 mysqli_close($con);

?>

