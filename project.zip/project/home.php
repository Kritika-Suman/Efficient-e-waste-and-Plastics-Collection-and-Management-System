<!DOCTYPE html>
<!--[if IE 8 ]><html class="no-js oldie ie8" lang="en"> <![endif]-->
<!--[if IE 9 ]><html class="no-js oldie ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]-->
<head>

   <!--- basic page needs
   ================================================== -->
   <meta charset="utf-8">
	<title>Kritika</title>
	<meta name="description" content="">  
	<meta name="author" content="">

   <!-- mobile specific metas
   ================================================== -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

 	<!-- CSS
   ================================================== -->
   <link rel="stylesheet" href="css/base.css">
   <link rel="stylesheet" href="css/vendor.min.css">
   <link rel="stylesheet" href="css/main.css">     

   <!-- script
   ================================================== -->
	<script src="js/modernizr.js"></script>

   <!-- favicons
	================================================== -->
	<link rel="shortcut icon" href="favicon.png" >

</head>

<body>

	<!-- header
   ================================================== -->
   <header id="main-header">

   	<div class="row">

	      <div class="logo">
	         <a href="home.php">Kritika</a>
	      </div>

	      <nav id="nav-wrap">         
	         
	         <a class="mobile-btn" href="#nav-wrap" title="Show navigation">
	         	<span class="menu-icon">Menu</span>
	         </a>
         	<a class="mobile-btn" href="#" title="Hide navigation">
         		<span class="menu-icon">Menu</span>
         	</a>            

	         <ul id="nav" class="nav">
	            <li><a class="smoothscroll" href="#hero">Home.</a></li>
	            <li><a class="smoothscroll" href="#services">Services.</a></li>
	            <li><a class="smoothscroll" href="#about">About.</a></li>
	            <li><a class="smoothscroll" href="#contact">Contact.</a></li>
	         </ul> <!-- end #nav -->

	      </nav> <!-- end #nav-wrap -->

	      <ul class="header-social">
	        	<li><a href="#"><i class="fa fa-facebook"></i></a></li>
	        	<li><a href="#"><i class="fa fa-twitter"></i></a></li>
	        	<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
	      </ul>      

	   </div>

   </header> <!-- end header -->


   <!-- homepage hero
   ================================================== -->
   <section id="hero">	
   	  
		<div class="row hero-content">

			<div class="twelve columns hero-container">

			   <!-- hero-slider start-->
			   <div id="hero-slider" class="flexslider">

				   <ul class="slides">

					   <!-- slide -->
					   <li>
						   <div class="flex-caption">
								<h1 class="">Efficient e-Waste and Plastics Collection and Management System
								</h1>	
									
								<h3 class="">a step towards 'swachh bharat and safe bharat'</h3>				   
							</div>						
					   </li>

					   <!-- slide -->
					   <li>						
							<div class="flex-caption">
								<h1 class="">e-Waste</h1>

								<h3 class="">India has emerged as fifth largest e-waste producer in the world.</h3>			   
							</div>					
					   </li>

					   <!-- slide -->
					   <li>
						   <div class="flex-caption">
								<h1 class="">Plastics</h1>

								<h3 class="">5000 tonnes of plastic waste are generated in India everyday, of which 6000 tonnes remain uncollected and littered.</h3>			   
							</div>
					   </li>					              

				   </ul>

			   </div> <!-- end hero-slider -->				   

	      </div> <!-- end twelve columns-->

		</div> <!-- end row -->	

		<div id="more">
		      <a class="smoothscroll" href="#services">More About Us<i class="fa fa-angle-down"></i></a>
		</div> 	

   </section> <!-- end homepage hero -->


   <!-- Services Section
   ================================================== -->
   <section id="services">

   	<div class="row section-head">

      	<div class="twelve columns">

      		<h1>Our Awesome Services<span>.</span></h1>

	         <hr />      	         

            <p><marquee>Welcome to the website of e-waste and plastics collection and management system</marquee>
	         </p>

	      </div>

      </div> <!-- end section-head -->

      <div class="row mobile-no-padding">      	

	      <div class="service-list bgrid-third s-bgrid-half tab-bgrid-whole group">
              
	      	<div class="bgrid">	               

	            <h3>Environment.</h3>

	            <div class="service-content">	                  
		            <p>
                        "Lets move towards sustainability."
	         		</p> 
	         	</div>  

				</div> <!-- end bgrid --> 

				<div class="bgrid">	              

	            <h3>e-Waste.</h3>                  

	            <div class="service-content">	                  
		            <p>
                       The current rates of e-waste are as follows:
                        <ul>
                            <li>For items like toner/ tube light/ bulb/CFL/cartridges/cd/ floppy/dvd we will provide
                                the clients Rs 70/kg.</li>
                            <li>Other items, price is Rs.5/Kg for all e-waste.</li>
                       </ul>
	         		</p> 
	            </div>	              

			   </div> <!-- end bgrid -->

			   <div class="bgrid">	              

	            <h3>Plastics.</h3>

	            <div class="service-content">		                  
		            <p>
                       The current rates of plastics are as follows:
                        <ul>
                            <li>Rates varies from Rs. 25 to 75 per kg depending upon the plstics.</li>
                       </ul> 
	                </p> 
	            </div> 	               

			   </div> <!-- end bgrid -->

				

	      </div> <!-- end service-list -->	      

      </div> <!-- end row -->      

   </section> <!-- end services -->

    
   <!--
        --------------------------------------------------------------------------------------------
   -->
     <div id="call-to-action">	       

		   <div class="row section-ads">

		      <div class="twelve columns">		         	

				<div class="action">
			         <a href="sign-up/signUp.php" >Sign Up / Log In</a>
	         	</div>
                  
			  </div>

		   </div> <!-- end section-ads -->		         	         

	   </div> <!-- end call-to-action -->

    <!--
        --------------------------------------------------------------------------------------------
   -->

   <!-- About Section
   ================================================== -->
   <section id="about">

   	<div class="row section-head">

      	<div class="twelve columns">

      		<h1>Who Are We<span>.</span></h1>

	         <hr />     	    

	         <p>As the time of technology advances, with every passing second production of e-waste and plastics would 
                multiplicate itelf. Collection and management of e-waste and plasics has emerged as a big challenge to 
                the society that is at its hight of development.<br/>
                 
                We at the committee of e-waste and plastics management aim to deal efficiently with them effieciently.
	         </p>

	      </div> <!-- end section-head -->

      </div>

      <div class="row mobile-no-padding">       	

      	<div class="process bgrid-half tab-bgrid-whole group">

      		<div class="bgrid">

			      <h3>Our Process.</h3>	

			      <p>1. Visit the website, get yourself registerd.<br/>
                     2. Login to your dashboard.<br/>
                     3. Provide the neccessary details.<br/>  
                     4. Click on go button.<br/> 
                     5. Your request to dispose off the e-waste and plastics would be accepted.<br/>  
			      </p>

		   	</div>

      		<div class="bgrid">

			     <h3>Our Approach.</h3>

			     <p>On the specified date and time, a pick person would go the mentioned address.<br/>
                    There he would analyse and collect the waste<br/>
                    Depending on the amount of waste collected and the current market rate,
                    the person disposing off the waste would be awarded by some amount of money. 
			   	</p>	

		      </div> 

		      <div class="bgrid">

			     	<h3>Our Goal.</h3>	

			     	<p>* Efficient collection and management of e-waste and plastics.<br/>
                       * Making their disposal an easy process.<br/> 
                       * Providing a stable and well paid employment opportunity to the people who were forced to pick raggs
                        in order to sustain their lives.
			      </p>

		      </div>

		      <div class="bgrid">

			      <h3>Our Mission.</h3>

                  <p>"A jouney towards safety and sustainability."
			      </p>	

		      </div>

      	</div> <!-- end process -->      	

     	</div> <!-- end row -->    

   </section> <!-- end about -->  


   <!-- Testimonials Section
   ================================================== -->
   <section id="testimonials">

      <div class="row content flex-container">
    
         <div id="testimonial-slider" class="flexslider">

            <ul class="slides">
               <li>
                  <p>"Innovation is what makes the difference."
                  </p>

                  <div class="testimonial-author">
                    	<img src="images/team/member01-k.jpg" alt="Author image">
                    	<div class="author-info">
                    		Kritika Suman
                    		<span class="position">Creative Director</span>
                    	</div>
                  </div>
             	</li> <!-- end slide -->

               <li>                       
                  <p>"Leading towards a better tommorow."
                  </p>
                  <div class="testimonial-author">
                    	<img src="images/team/member03-k.jpg" alt="Author image">
                    	<div class="author-info">
                    		Ashwini Bhojane
                    		<span>Lead Designer</span>
                    	</div>
                  </div>                        
               </li> <!-- end slide -->

            </ul> <!-- end slides -->

         </div> <!-- end flexslider -->         
        
      </div> <!-- end row -->

   </section> <!-- end testimonials section -->  


   <!-- contact
   ================================================== -->
   <section id="contact">

   	<div class="row section-head">

   		<div class="twelve columns">

	         <h1>Get In Touch With Us<span>.</span></h1>

	         <hr />	        

	      </div>

      </div> <!-- end section-head -->

      <div class="row">
      	
      	<div id="contact-form" class="six columns tab-whole left">

            <!-- form -->
            <form name="contactForm" id="contactForm" method="post" action="contact.php"  >
      			<fieldset>

                  <div class="group">
 						   <input name="contactName" type="text" id="contactName" placeholder="Name" value="" minLength="2" required />
                  </div>
                  <div>
	      			   <input name="contactEmail" type="email" id="contactEmail" placeholder="Email" value="" required />
	               </div>
                  <div>
	     				   <input name="contactSubject" type="text" id="contactSubject" placeholder="Subject"  value="" />
	               </div>                       
                  <div>
	                 	<textarea name="contactMessage"  id="contactMessage" placeholder="message" rows="10" cols="50" required ></textarea>
	               </div>                      
                  <div>
                     <button class="submitform">Submit</button>
                     <div id="submit-loader">
                        <div class="text-loader">Sending...</div>                             
       				      <div class="s-loader">
								  	<div class="bounce1"></div>
								  	<div class="bounce2"></div>
								  	<div class="bounce3"></div>
								</div>
							</div>
                  </div>

      			</fieldset>
      		</form> <!-- Form End -->

            <!-- contact-warning -->
            <div id="message-warning"></div>
            <!-- contact-success -->
      		<div id="message-success">
               <i class="icon-ok"></i>Your message was sent, thank you!<br />
      		</div>

         </div>

         <div class="six columns tab-whole right">

            <p class="lead">"The case for recycling is strong. The bottom line is clear. Recycling requires a trivial amount of our time. Recycling saves money and reduces pollution. Recycling creates more jobs than landfilling or incineration. And a largely ignored but very important consideration, recycling reduces our need to dump our garbage in someone else’s backyard." – David Morris
                
	         <h3 class="address">Come and Visit Us</h3>

	         <p>
            24/6<br>
            e-Waste and Plastics Managing Committee<br>
            M.G. Road<br/> 
            Pune<br/>
            Maharashtra<br/>     
            </p>

            <h3>Contact Numbers:</h3>
			   <p>
			   	Mobile: +91 9876543210<br/>
                e-mail: k@gmail.com   
                   
			   </p>
               	
         </div>     	

      </div> <!-- end row -->     

   </section>  <!-- end contact -->


   <!-- Footer
   ================================================== -->
   <footer>

      <div class="row">  

      	<div class="twelve columns content group">
      		
				<ul class="social-links">
               <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
               <li><a href="#"><i class="fa fa-twitter-square"></i></a></li>
               <li><a href="#"><i class="fa fa-google-plus-square"></i></a></li>               
               <li><a href="#"><i class="fa fa-youtube-play"></i></a></li>
               <li><a href="#"><i class="fa fa-vimeo-square"></i></a></li>
               <li><a href="#"><i class="fa fa-flickr"></i></a></li>               
               <li><a href="#"><i class="fa fa-skype"></i></a></li>
            </ul>

            <hr />

            <div class="info">

            	<div class="footer-logo"></div>

	            <p> 
	            </p>	        

	         </div>

      	</div>           

        

         <div id="go-top">
            <a class="smoothscroll" title="Back to Top" href="#hero">Back to Top<i class="fa fa-angle-up"></i></a>
         </div>

      </div> <!-- end row -->

   </footer> <!-- end footer -->

   <div id="preloader"> 
    	<div id="loader"></div>
   </div> 

   <!-- Java Script
   ================================================== --> 
   <script src="js/jquery-1.11.3.min.js"></script>
   <script src="js/jquery-migrate-1.2.1.min.js"></script>
   <script src="js/jquery.flexslider-min.js"></script>
   <script src="js/jquery.waypoints.min.js"></script>
   <script src="js/jquery.validate.min.js"></script>
   <script src="js/jquery.fittext.js"></script>
   <script src="js/jquery.placeholder.min.js"></script>
   <script src="js/jquery.magnific-popup.min.js"></script>  
   <script src="js/main.js"></script>

</body>

</html>